=== AddQuicktag ===
Contributors: Bueltge
Donate link: http://bueltge.de/wunschliste/
Tags: quicktag, editor
Requires at least: 1.5
Tested up to: 2.8-bleeding-edge 
Stable tag: 0.3

This plugin make it easy, Quicktags add to the editor. It is possible to ex- and import your Quicktags.

== Description ==
WP-AddQuicktag for Wordpress is in originally by [Roel Meurders](http://roel.meurders.nl/ "Roel Meurders"). AddQuicktag is an newer version with more functions and worked in WP 2.1

Please visit [the official website](http://bueltge.de/wp-addquicktags-de-plugin/120 "AddQuicktag") for further details and the latest information on this plugin.


== Installation ==
1. Unpack the download-package
1. Upload the files to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Got to 'Options' menu and configure the plugin

See on [the official website](http://bueltge.de/wp-addquicktags-de-plugin/120 "AddQuicktag").


== Screenshots ==
1. options-area
2. editor with new Quicktags
3. Comment-Editor with new Quicktags


== Other Notes ==
= Acknowledgements =
Thanks to Yuuich on [www.u-1.net](http://www.u-1.net/ "Yuuich") for translate the plugin in japanese, Neil on [www.wmfield.idv.tw](http://www.wmfield.idv.tw/ "Yuuich") for translate the plugin in chinese, [Jean-Michel MEYER](http://www.li-an.fr/blog "Jean-Michel MEYER") for translate in french, italien translation by [Gianni Diurno](http://gidibao.net/ "Gianni Diurno") and Josef Klimosz on [http://blog.rudice.cz/](http://blog.rudice.cz/ "Josef Klimosz") for the czech language file.

= Licence =
Good news, this plugin is free for everyone! Since it's released under the GPL, you can use it free of charge on your personal or commercial blog. But if you enjoy this plugin, you can thank me and leave a [small donation](http://bueltge.de/wunschliste/ "Wishliste and Donate") for the time I've spent writing and supporting this plugin. And I really don�t want to know how many hours of my life this plugin has already eaten ;)

= Translations =
The plugin comes with various translations, please refer to the [WordPress Codex](http://codex.wordpress.org/Installing_WordPress_in_Your_Language "Installing WordPress in Your Language") for more information about activating the translation. If you want to help to translate the plugin to your language, please have a look at the sitemap.pot file which contains all defintions and may be used with a [gettext](http://www.gnu.org/software/gettext/) editor like [Poedit](http://www.poedit.net/) (Windows).

== Frequently Asked Questions ==
= Where can I get more information? =
Please visit [the official website](http://bueltge.de/wp-addquicktags-de-plugin/120 "AddQuicktag") for the latest information on this plugin.

= I love this plugin! How can I show the developer how much I appreciate his work? =
Please visit [the official website](http://bueltge.de/wp-addquicktags-de-plugin/120 "AddQuicktag") and let him know your care or see the [wishlist](http://bueltge.de/wunschliste/ "Wishlist") of the author.